<?php $__env->startSection('title', 'Detail Pesanan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <h2 class="mb-4">Detail Pesanan #<?php echo e($order->id); ?></h2>
    <p><strong>Status:</strong> <?php echo e($order->status); ?></p>

    <div class="table-responsive">
        <table class="table table-bordered align-middle">
            <thead class="table-dark">
                <tr>
                    <th>Produk</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php $total = 0; ?>
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $subtotal = $item->price * $item->quantity;
                        $total += $subtotal;
                    ?>
                    <tr>
                        <td><?php echo e($item->product->name); ?></td>
                        <td>Rp<?php echo e(number_format($item->price, 0, ',', '.')); ?></td>
                        <td><?php echo e($item->quantity); ?></td>
                        <td>Rp<?php echo e(number_format($subtotal, 0, ',', '.')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="3" class="text-end"><strong>Total:</strong></td>
                    <td><strong>Rp<?php echo e(number_format($total, 0, ',', '.')); ?></strong></td>
                </tr>
            </tbody>
        </table>
    </div>

    <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-secondary mt-3">← Kembali ke Riwayat</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tubes-app\resources\views/orders/show.blade.php ENDPATH**/ ?>