<?php $__env->startSection('title', 'Dashboard User'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Header -->
    <header class="bg-dark py-5">
        <div class="container px-4 px-lg-5 my-5">
            <div class="text-center text-white">
                <h1 class="display-4 fw-bolder">Parfum Berkualitas</h1>
                <p class="lead fw-normal text-white-50 mb-0">Aroma Elegan untuk Hari Anda</p>
            </div>
        </div>
    </header>
    
     <?php if(session('success')): ?>
    <div class="max-w-xl mx-auto mt-4">
        <div class="bg-green-100 border border-green-300 text-green-800 px-4 py-2 rounded shadow-sm text-sm flex items-center justify-between">
            <span>✅ <?php echo e(session('success')); ?></span>
        </div>
    </div>
<?php endif; ?>
    <!-- Section: Products -->
    <section class="py-5">
        <div class="container px-4 px-lg-5 mt-5">
            <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image -->
                            <img class="card-img-top" src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" />

                            <!-- Product details -->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <h5 class="fw-bolder"><?php echo e($product->name); ?></h5>
                                    <p class="mb-1"><?php echo e(Str::limit($product->description, 50)); ?></p>
                                    <span class="fw-bold text-primary">Rp<?php echo e(number_format($product->price, 0, ',', '.')); ?></span>
                                </div>
                            </div>

                            <!-- Product actions -->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center">
                                    <form action="<?php echo e(route('cart.add', $product->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-outline-dark mt-auto">Add to cart</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tubes-app\resources\views/user/dashboarduser.blade.php ENDPATH**/ ?>