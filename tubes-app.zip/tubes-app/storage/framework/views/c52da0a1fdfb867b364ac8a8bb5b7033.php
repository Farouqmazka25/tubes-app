<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h3 class="mb-4">Keranjang Belanja</h3>

    <?php if(count($items) > 0): ?>
        <table class="table table-bordered align-middle">
            <thead class="table-dark">
                <tr>
                    <th>Produk</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Subtotal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->product->name); ?></td>
                    <td>Rp<?php echo e(number_format($item->product->price, 0, ',', '.')); ?></td>
                    <td>
                        <form action="<?php echo e(route('cart.update', $item->id)); ?>" method="POST" class="d-flex">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input type="number" name="quantity" value="<?php echo e($item->quantity); ?>" min="1" class="form-control me-2" style="width: 80px;">
                            <button type="submit" class="btn btn-sm btn-primary">Update</button>
                        </form>
                    </td>
                    <td>Rp<?php echo e(number_format($item->product->price * $item->quantity, 0, ',', '.')); ?></td>
                    <td>
                        <form action="<?php echo e(route('cart.remove', $item->id)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus item ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="3" class="text-end"><strong>Total</strong></td>
                    <td colspan="2"><strong>Rp<?php echo e(number_format($total, 0, ',', '.')); ?></strong></td>
                </tr>
            </tbody>
        </table>

        
        <form action="<?php echo e(route('checkout')); ?>" method="POST">
            <?php echo csrf_field(); ?>   
            <button type="submit" class="btn btn-success">Checkout Sekarang</button>
        </form>
    <?php else: ?>
        <p class="text-muted">Keranjang kamu masih kosong.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tubes-app\resources\views/cart/index.blade.php ENDPATH**/ ?>