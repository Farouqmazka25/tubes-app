<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="text-center my-auto">
            <span>Copyright &copy;
                <?php echo e(date('Y')); ?> MYKONOS</span>
        </div>
    </div>
</footer>
<?php /**PATH C:\laragon\www\tubes-app\resources\views/layouts/admin/footer.blade.php ENDPATH**/ ?>