<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title><?php echo $__env->yieldContent('title', 'Lelang Parfum'); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet" />

    <style>
        html, body {
            height: 100%;
        }
        body {
            display: flex;
            flex-direction: column;
            background-color: #f8f9fa;
        }
        main {
            flex: 1;
        }

        .navbar-custom {
            background-color: #141B24 !important; /* warna navbar diselaraskan */
        }
        .navbar-custom .nav-link,
        .navbar-custom .navbar-brand {
            color: white !important;
        }
        .navbar-custom .nav-link.active {
            font-weight: bold;
            text-decoration: underline;
        }
    </style>
</head>
<body>

    
    <?php if(!Request::is('login') && !Request::is('register')): ?>
    
    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container px-4 px-lg-5">
            <a class="navbar-brand" href="#">MYKONOS</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">

                
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                    <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item"><a class="nav-link <?php echo e(Route::is('dashboard.user') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard.user')); ?>">Home</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo e(Route::is('orders.index') ? 'active' : ''); ?>" href="<?php echo e(route('orders.index')); ?>">Riwayat</a></li>
                    <?php endif; ?>
          
                </ul>

                
                <div class="d-flex align-items-center gap-2">
                    <?php if(auth()->guard()->check()): ?>
                        
                        <?php if (! (Route::is('cart.index'))): ?>
                            <a class="btn btn-outline-light" href="<?php echo e(route('cart.index')); ?>">
                                <i class="bi-cart-fill me-1"></i>
                                Cart
                                <span class="badge bg-light text-dark ms-1 rounded-pill"><?php echo e($cartCount ?? 0); ?></span>
                            </a>
                        <?php endif; ?>

                        
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-danger" type="submit">Keluar</button>
                        </form>
                    <?php endif; ?>

                    <?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(route('login.form')); ?>" class="btn btn-primary">Login</a>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </nav>
    <?php endif; ?>
    

    
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
        
    
    <?php if(!Request::is('login') && !Request::is('register')): ?>
    <footer class="py-4 text-white mt-auto" style="background-color: #141B24;">
        <div class="container text-center">
            <p class="mb-0">&copy; MYKONOS Indonesia <?php echo e(date('2025')); ?></p>
        </div>
    </footer>
    <?php endif; ?>
    

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\tubes-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>