<?php $__env->startSection('content'); ?>
    <h4>Daftar Pesanan</h4>

    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama User</th>
                <th>Status</th>
                <th>Tracking Number</th> 
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td><?php echo e($order->user->name ?? '-'); ?></td>
                    <td><?php echo e($order->status); ?></td>
                    <td><?php echo e($order->tracking_number ?? '-'); ?></td> 
                    <td>
                        <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>" class="btn btn-sm btn-info">Detail</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tubes-app\resources\views/admin/orders.blade.php ENDPATH**/ ?>