

<?php $__env->startSection('title', 'Checkout Berhasil'); ?>

<?php $__env->startSection('content'); ?>
<div class="container text-center mt-5">
    <h2 class="text-success mb-4">✅ Checkout Berhasil!</h2>
    <p>Terima kasih telah melakukan pembelian.</p>

    <div class="my-4">
        <a href="<?php echo e(route('user.checkout')); ?>" class="btn btn-primary">Kembali ke Beranda</a>
    </div>

    <img src="<?php echo e(asset('img/checkout_success.png')); ?>" alt="Checkout Success" style="max-width: 300px;" class="mt-3">
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tubes-app\resources\views/user/checkout.blade.php ENDPATH**/ ?>