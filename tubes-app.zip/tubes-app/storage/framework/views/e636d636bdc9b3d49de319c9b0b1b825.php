

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Keranjang Belanja</h3>
    <p>Belum ada item di keranjang.</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tubes-app\resources\views/user/cart.blade.php ENDPATH**/ ?>