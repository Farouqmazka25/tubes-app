<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="text-center my-auto">
            <span>Copyright &copy;
                {{ date('Y') }} MYKONOS</span>
        </div>
    </div>
</footer>
