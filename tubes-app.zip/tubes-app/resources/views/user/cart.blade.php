@extends('layouts.app')

@section('content')
<div class="container">
    <h3>Keranjang Belanja</h3>
    <p>Belum ada item di keranjang.</p>
</div>
@endsection